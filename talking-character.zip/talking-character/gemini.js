// Import required modules
import fetch from "node-fetch";

// Define your constants
const LANGUAGE_MODEL_API_KEY = "AIzaSyBvYCHR0GhIYDLEG2dx7na7su4EZA06aw8";
const ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${LANGUAGE_MODEL_API_KEY}`;

/**
 * Send a prompt to Gemini API and get response
 * @param {string} prompt - The text prompt to send
 * @returns {Promise<string>} The generated response text
 */
const sendRequest = async (prompt) => {
  if (!prompt || typeof prompt !== "string") {
    throw new Error("Prompt must be a non-empty string");
  }

  const requestData = {
    contents: [
      {
        parts: [
          {
            text: prompt,
          },
        ],
      },
    ],
  };

  try {
    const response = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`API Error: ${response.status} - ${errorBody}`);
    }

    const data = await response.json();

    if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
      throw new Error("Invalid response format from API");
    }

    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error("Request failed:", error);
    throw error;
  }
};

// Example usage
const prompt = "Tell me about VTC in Hong Kong";
sendRequest(prompt)
  .then((response) => console.log("Response:", response))
  .catch((error) => console.error("Error:", error));

export default sendRequest;
