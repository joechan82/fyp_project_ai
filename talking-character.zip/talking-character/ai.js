// Import required modules
import fetch from "node-fetch";
import { GoogleAuth } from "google-auth-library";
import { readFileSync } from "fs";

// Load the service account key JSON file
const serviceAccountKey = JSON.parse(
  readFileSync(
    "/workspaces/vtcAi_project/talking-character/vtc-ai-440901-49ad452543b6.json",
    "utf8",
  ),
);

// Create a Google Auth client
const auth = new GoogleAuth({
  credentials: serviceAccountKey,
  scopes: ["https://www.googleapis.com/auth/cloud-platform"],
});

// Function to get the access token
const getAccessToken = async () => {
  const client = await auth.getClient();
  const accessToken = await client.getAccessToken();
  return accessToken.token;
};

// Define your constants
const ENDPOINT = "us-central1-aiplatform.googleapis.com";
const PROJECT_ID = "vtc-ai-440901";
const REGION = "us-central1";

// Construct the URL for the API request
const url = `https://${ENDPOINT}/v1beta1/projects/${PROJECT_ID}/locations/${REGION}/endpoints/openapi/chat/completions`;

// Define the request payload
const texts = "do you hk vtc";
const requestData = {
  model: "meta/llama-3.2-90b-vision-instruct-maas",
  stream: false,
  messages: [
    {
      role: "user",
      content: [
        {
          text: texts,
          type: "text",
        },
      ],
    },
  ],
  max_tokens: 40,
  temperature: 0.4,
  top_k: 10,
  top_p: 0.95,
  n: 1,
};

// Main function to send the request
const sendRequest = async () => {
  const accessToken = await getAccessToken(); // Get access token
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    });

    // Check if the response is ok (status code in the range 200-299)
    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(
        `HTTP error! Status: ${response.status}, Body: ${errorBody}`,
      );
    }

    const data = await response.json(); // Parse JSON response
    console.log("Response text:", data.choices[0].message.content); // Log the specific content
  } catch (error) {
    console.error("Error:", error); // Log any errors
  }
};

// Execute the function
sendRequest();






