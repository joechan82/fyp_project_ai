// src/server/index.js
import express from "express";
import cors from "cors";
import authRouter from "./get_auth_token.js";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());
app.use("/api/auth", authRouter);

app.listen(PORT, () => {
  console.log(`伺服器運行於 port ${PORT}`);
});
