import express from "express";
import { GoogleAuth } from "google-auth-library";

const router = express.Router();
const auth = new GoogleAuth({
  credentials: {
    type: "service_account",
    project_id: "vtc-ai-440901",
    private_key_id: "49ad452543b6b082fced7c2c7bf34c0c9f0d57d2",
    private_key:
      "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCt1v/VaH266gNy\nlNCnANj2/QkxnXPh/J4QoXnWs2qXEj8D5EPX6oqC7F9DQyqKGIfJY8wGw3ZeH0Br\n/xYH4M70SjVDq+ESPzg/YnjVpTtfEtCy/4JBxkMpIEN5NXwFAth5i/8MWjWCq24L\nlXxlj4Ekp+iqgdcuRnr7v7ErRdNNdp04MT7Y0mfWTK22TJsZylHdWko2YqLXcnLo\nR8fHrlhfjoXVWzZvkVW+OJoBSC1jxbkjHXcBLTO1Bi1lzZt7dirC7Xl7AGQ1o8lQ\no3TKyJeo+mIAjbQiHt6z0CCpegzNpC6yLLu+s9uoHYcvdJSz+D//ZSid847UlfVj\nyuYlRH/HAgMBAAECggEAIqbKHTh0Y3c1E7htNPTayrTaiczIZiIMQeVmG3FtDEsD\nS5vLGDV0wa8rOAWh66ADJRYi+7AnnpBdL4nL0usxZYmLP3954EDAzgWrb269vHBM\nMHn09XZ3ObHoMTeDjp4oF2ZcAxLSOsdAKsfz4WyvAecEXkR+Z4d+CUOHJciH25c2\nXNLw2QJjEx9YfvQoT1gzExMDW+NxEXtRKzwbGN9T8Rs2k+ulE0egt1MuszuoR5iG\n3LiPHOEknWZG1sjllkmX/ATD2HY2D1NVEB7riDBt9oonJ9tw9FReLo2NjdJhoe+z\n40Pwd/ISkgu7Z0YW8ibsj8/Xh6cuezL3IL4sotC9BQKBgQDjjUl1QpXzTrv/qAS4\nGiqL5ohMN8HINyJuLH+f20NnW2+NYpNypvqY6UGlkA+WAWo8MSSF0vIXBrZbV7NC\ngubWRI4JzNWVkTBUJmwViDVV4Yi96UvrjnAPkMOZaO1mg8e4d6qJiFjVWDqCL9zq\njIwELa25MS2+/sAboAmg99wKMwKBgQDDkq2Xjsjr//zcTECDYwINQEvEQ9juNGf9\n8Tnl2CB/Z/ttsS5palXGZ99Zq4sVOoBwMVlt3XVkc9t4jmgtipIMdFMc11Qn02MO\nuYREIF7BNNvy2W2G2rvXM9QtHr8fGGIOIdH9JaONIl4n2c9zq7ZLdmN3jDsaxmTw\nQelvkKNIHQKBgGWboUGLCgorDieKjxDmHjl6J0JhY1ZTyDwKArMO5Xoxig5IBi8c\nAKpm/blAKrWAzD80cmqPVyqRBLyk3JbGfO0Qj5wwqu6udjYdMgYrXCWNH9Itaok0\ngTVyHuVRxTARiA0G4k+nYoNhcj7PwIW7XIpBG2GmZBb1CjNLswD9rHOhAoGAAYu5\nP4drYyIk14DqyZ8QtxYZAzYeEtPrNoCfmod4ykkCHb3WxhKHFwhfJZBLiyFpPnnF\nYS7s7JxV0cAeZq2/tcV9mq7BBYeQMt+YgglXdmN6kZLSYMx9y5enR6wEirRgogf2\nZu/TORxabio0j499417OLnW3SeDjj1qWA8G66KkCgYA28toCi3VlhN1Ih/TeEuJj\ndIG1tE2W6qsCSiCBDXtJXxn1KFRWUT6nLhX9lo2pJNvvb/tCfDCSh7Q/Pz1ODzbG\nBIB+Eq6h4dQLuEW1HMc1n/DbZbXoGDRBnJ+o43ExU+DW8jXtaMnWHrUtkl0OqV0O\ngyAa+DTyzjRKmHNpHBYyXQ==\n-----END PRIVATE KEY-----\n",
    client_email: "ai-service-account@vtc-ai-440901.iam.gserviceaccount.com",
    client_id: "111006588869947510503",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url:
      "https://www.googleapis.com/robot/v1/metadata/x509/ai-service-account%40vtc-ai-440901.iam.gserviceaccount.com",
    universe_domain: "googleapis.com",
  },
  scopes: ["https://www.googleapis.com/auth/cloud-platform"],
});

// GET /api/auth/token
router.get("/token", async (req, res) => {
  try {
    const client = await auth.getClient();
    const accessToken = await client.getAccessToken();
    res.json({ token: accessToken.token });
  } catch (error) {
    res.status(500).json({ error: "認證失敗" });
  }
});

export default router;
