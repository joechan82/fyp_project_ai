/**
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export const ENDPOINT = "us-central1-aiplatform.googleapis.com";

export const PROJECT_ID = "vtc-ai-440901";

export const REGION = "us-central1";

export const GOOGLE_CLOUD_API_KEY = "AIzaSyBvYCHR0GhIYDLEG2dx7na7su4EZA06aw8"; // Fill in your API key

export const LANGUAGE_MODEL_API_KEY = "AIzaSyBvYCHR0GhIYDLEG2dx7na7su4EZA06aw8"; // Fill in your API key

export const LANGUAGE_MODEL_BASE_URL ="https://generativelanguage.googleapis.com";

export const LANGUAGE_MODEL_NAME = "gemini-1.5-flash";

export const LANGUAGE_MODEL_URL = `${LANGUAGE_MODEL_BASE_URL}/v1beta/models/${LANGUAGE_MODEL_NAME}:generateContent?key=${LANGUAGE_MODEL_API_KEY}`;

export const Llama_MODEL_URL = `https://${ENDPOINT}/v1beta1/projects/${PROJECT_ID}/locations/${REGION}/endpoints/openapi/chat/completions`;
