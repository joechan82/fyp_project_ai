// import { useState } from "react";

// export const useLlamaApi = () => {
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   const sendMessage = async () => {
//     const message = "do you know aws?"; // 固定訊息
//     try {
//       setLoading(true);
//       // 取得認證 token
//       const tokenResponse = await fetch("http://localhost:3001/api/auth/token");
//       const { token } = await tokenResponse.json();

//       // 呼叫 Llama API
//       const response = await fetch(
//         `https://us-central1-aiplatform.googleapis.com/v1beta1/projects/vtc-ai-440901/locations/us-central1/endpoints/openapi/chat/completions`,
//         {
//           method: "POST",
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             messages: [
//               {
//                 role: "user",
//                 content: message,
//               },
//             ],
//             temperature: 0.7,
//             max_tokens: 100,
//           }),
//         },
//       );

//       const data = await response.json();
//       return data;
//     } catch (err) {
//       setError(err instanceof Error ? err.message : "發生錯誤");
//       throw err;
//     } finally {
//       setLoading(false);
//     }
//   };

//   return { sendMessage, loading, error };
// };
